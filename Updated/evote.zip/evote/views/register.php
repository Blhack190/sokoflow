<section id="registerView" class="view-panel">
  <div class="card-box" style="max-width: 600px; margin: auto;">
    <h2>Nominee Registration</h2>
    <form onsubmit="handleRegistration(event)">
      <input type="text" name="name" class="form-control" placeholder="Full Name" required>
      <input type="text" name="dept" class="form-control" placeholder="Learning Center" required>
      <select name="category" id="regCategory" class="form-control" required onchange="checkCategoryClosed(this.value)">
        <option value="" disabled selected>Select Category</option>
        <?php foreach (CATEGORIES as $cat): ?>
          <option value="<?php echo htmlspecialchars($cat, ENT_QUOTES); ?>"
            <?php echo in_array($cat, $closedCategoriesNow, true) ? 'data-closed="1"' : ''; ?>>
            <?php echo htmlspecialchars($cat, ENT_QUOTES); ?>
            <?php echo in_array($cat, $closedCategoriesNow, true) ? ' (Nominations Closed)' : ''; ?>
          </option>
        <?php endforeach; ?>
      </select>
      <p id="regClosedNote" class="status-msg" style="display:none; color:var(--err);">Nominations for this category are closed.</p>
      <input type="file" name="image" class="form-control" accept="image/*" required>
      <textarea name="bio" class="form-control" placeholder="Manifesto Summary" rows="4" required></textarea>
      <input type="password" name="password" class="form-control" placeholder="Create Password" required>
      <button type="submit" class="btn-action" id="regSubmitBtn">Submit Candidacy</button>
    </form>
  </div>
</section>
