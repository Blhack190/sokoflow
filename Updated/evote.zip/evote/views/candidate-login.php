<section id="candidateLoginView" class="view-panel">
  <div class="card-box" style="max-width: 400px; margin: auto;">
    <h2 style="text-align: center; color: var(--color-accent);">Candidate Login</h2>
    <input type="text" id="candCode" class="form-control" placeholder="Nominee Code (e.g., DE004)">
    <input type="password" id="candPass" class="form-control" placeholder="Password">
    <button class="btn-action" onclick="handleCandidateLogin()">Login</button>
  </div>
</section>
