<header>
  <div class="brand">
    <img src="uploads/logo1.jpg" alt="Logo 1" class="brand-logo-circle" onerror="this.style.display='none'">
    <img src="uploads/logo2.jpg" alt="Logo 2" class="brand-logo-circle" onerror="this.style.display='none'">
    <div class="brand-seal" aria-hidden="true">JCR</div>
    <div>
      <div class="brand-name">UGDE&nbsp;&middot;&nbsp;JCR</div>
      <div class="brand-tag">Official E-Voting Portal</div>
    </div>
  </div>
  <nav>
    <button class="nav-btn active" onclick="switchView('votingView', this)">Vote</button>
    <button class="nav-btn" onclick="switchView('registerView', this)">Register</button>
    <button class="nav-btn" onclick="switchView('adminLoginView', this)">Admin</button>
    <button class="nav-btn" onclick="switchView('candidateLoginView', this)">Candidate</button>
  </nav>
</header>
