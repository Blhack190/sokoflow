<footer>
  <p>&copy; 2026 UGDE-JCR Elections | Developed by Cimon &amp; Charles</p>
</footer>
