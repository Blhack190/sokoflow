<section id="adminDashboardView" class="view-panel">
  <div class="card-box">
    <h1>Analytics</h1>
    <p>Total Votes: <strong id="statVotes">0</strong> | Revenue: <strong id="statRev" style="color:var(--color-accent)">GHS 0.00</strong></p>
  </div>

  <div class="card-box">
    <h3>Vote Distribution</h3>
    <div style="margin: 1rem 0 0.5rem;">
      <select id="chartCategoryFilter" class="form-control" style="max-width:340px;" onchange="applyChartFilter()">
        <option value="">All Categories</option>
      </select>
    </div>
    <div class="chart-container">
      <canvas id="voteChart"></canvas>
    </div>
  </div>

  <div class="card-box" style="max-width:500px">
    <h3>Update Security</h3>
    <input type="password" id="newAdminPass" class="form-control" placeholder="New Password">
    <button class="btn-action" onclick="changeAdminPassword()">Update</button>
  </div>

  <div class="card-box">
    <h3>Manage Nominations</h3>
    <p style="color:var(--slate-400); font-size:0.88rem; margin-bottom:0.75rem;">Toggle a category to open or close new candidate submissions for it. Existing candidates and votes are unaffected.</p>
    <div id="categoryStatusList"></div>
  </div>

  <div class="card-box">
    <h3>Nominees</h3>
    <table>
      <thead>
        <tr>
          <th>Candidate</th>
          <th>Category</th>
          <th>Code</th>
          <th>Votes</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="adminTableBody"></tbody>
    </table>
  </div>

  <!-- PAYMENT HISTORY with Search -->
  <div class="card-box">
    <h3 style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
      <span>Payment History</span>
      <button class="btn-action toggle-payments" onclick="togglePayments()" style="width:auto; padding:0.4rem 1.2rem; margin:0;">View</button>
    </h3>

    <div id="paymentHistoryContainer" style="display:none; margin-top:1rem;">
      <input type="text" id="paymentSearch" class="form-control"
             placeholder="Search by reference, email, name or candidate ID..."
             style="max-width:360px; margin-bottom:1rem;">

      <div class="payment-table-wrap">
        <table>
          <thead>
            <tr>
              <th>Ref</th>
              <th>Voter</th>
              <th>Email</th>
              <th>Candidate</th>
              <th>Qty</th>
              <th>Amount (GHS)</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody id="paymentTableBody">
            <tr><td colspan="8" style="text-align:center; color:var(--slate-400);">Loading payments...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
