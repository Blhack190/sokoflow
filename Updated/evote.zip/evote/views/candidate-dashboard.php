<section id="candidateDashboardView" class="view-panel">
  <div class="card-box">
    <h2 id="candName"></h2>
    <p>Code: <strong id="candCodeDisplay"></strong> | Department: <span id="candDept"></span></p>
    <p style="margin-top:0.3rem; color:var(--gold-500);">Category: <span id="candCategory"></span></p>
    <div style="margin: 1.5rem 0;">
      <div class="candidate-stats">
        <div class="stat-item"><span style="color:var(--slate-400)">Your Votes</span><br><span id="candVotes" style="font-size:2rem;font-weight:700;">0</span></div>
        <div class="stat-item"><span style="color:var(--slate-400)">Category Total</span><br><span id="candTotalVotes" style="font-size:2rem;font-weight:700;">0</span></div>
        <div class="stat-item"><span style="color:var(--slate-400)">Your Share</span><br><span id="candShare" style="font-size:2rem;font-weight:700;">0%</span></div>
      </div>
      <p style="margin-top:0.8rem;">Progress within your category:</p>
      <div class="progress-bar-container">
        <div class="progress-bar-fill" id="candProgressBar" style="width:0%;"></div>
      </div>
    </div>
    <button class="btn-action" onclick="handleCandidateLogout()" style="width:auto; padding:0.5rem 2rem;">Logout</button>
  </div>
</section>
