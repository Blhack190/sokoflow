<!-- VOTE MODAL -->
<div id="voteModal">
  <div class="modal-content">
    <h2>Cast Vote</h2>
    <p id="modalCName" class="modal-sub"></p>
    <input type="hidden" id="v_cid">
    <input type="text" id="v_name" class="form-control" placeholder="Full Name (Required)" required>
    <input type="tel" id="v_phone" class="form-control" placeholder="Phone Number (Required)" required>
    <input type="email" id="v_email" class="form-control" placeholder="Email Address (Required)" required>
    <input type="number" id="v_qty" class="form-control" value="1" min="1">
    <p>Total: <span style="color:var(--color-accent); font-weight:bold;">GHS <span id="v_total">1.00</span></span></p>
    <button class="btn-action" id="payBtn" onclick="initiatePaystack()">Pay Now</button>
    <button class="btn-ghost" onclick="closeModal()">Cancel</button>
    <p class="status-msg" id="v_status"></p>
  </div>
</div>

<!-- CANDIDATE VIEW MODAL (Admin) -->
<div id="candidateViewModal">
  <div class="modal-content">
    <h2>Candidate Application</h2>
    <div id="candidateViewContent"></div>
    <button class="btn-ghost" onclick="closeCandidateView()">Close</button>
  </div>
</div>
