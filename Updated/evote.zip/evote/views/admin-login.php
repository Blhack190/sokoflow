<section id="adminLoginView" class="view-panel">
  <div class="card-box" style="max-width: 400px; margin: auto;">
    <h2 style="text-align: center; color: var(--color-accent);">Admin Dashboard</h2>
    <input type="text" id="admUser" class="form-control" placeholder="Username">
    <input type="password" id="admPass" class="form-control" placeholder="Password">
    <button class="btn-action" id="adminLoginBtn" onclick="handleAdminLogin()">Login</button>
  </div>
</section>
