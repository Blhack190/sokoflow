<section id="votingView" class="view-panel active">
  <div id="categoryTip" class="tip-bar">
    <span>💡 <strong>Tip:</strong> Use the filter below to quickly view a specific category.</span>
    <button class="close-tip" onclick="document.getElementById('categoryTip').style.display='none'" aria-label="Dismiss tip">&times;</button>
  </div>

  <div class="filter-row">
    <label for="categoryFilter">Filter by category:</label>
    <select id="categoryFilter" class="form-control" style="display:inline-block; width:auto; max-width:280px; background:rgba(0,0,0,0.3);">
      <option value="all">All Categories</option>
    </select>
  </div>

  <div id="contestantsGrid"></div>
</section>
