<?php
/**
 * UGDE-JCR Voting Platform - Configuration
 */

define('APP_NAME', 'UGDE-JCR Official Electoral Voting Portal');
define('UNIT_PRICE_PER_VOTE', 1.00);

define('CATEGORIES', [
    'Most Influential Student of the Year',
    'Student Entrepreneur of the Year',
    'Outstanding JCR Executive',
    'Most Popular Male of the Year',
    'Most Popular Female of the Year',
    'Most Fashionable Student of the Year',
    'Best Student Politician',
    'Best Level 100 Course Rep',
    'Best Level 200 Course Rep',
    'Best Level 300 Course Rep',
    'Best Level 400 Course Rep',
    'Student Activist of the Year',
    'Best Department in UG-DE',
    'Face of DE',
]);

// IMPORTANT: Move these to environment variables in production
define('PAYSTACK_SECRET_KEY', 'sk_live_6d2ab6e482d7c91fbb2c7b609c637d2f0e49a2cb');
define('PAYSTACK_SPLIT_CODE', 'SPL_QlDRCk21vm');